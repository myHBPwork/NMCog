#This builds and test a two state FSA.  It calls the test functions
#in the FSAClass.  It should have the same results as testFSA.py.
#state 0 and input 1 turns on state 2.  2 turns off 1 and 0.

#change the simulator name to run nest or spinnaker
simulator = "nest"
#simulator = "spinnaker"

import nest as nest
import pyNN.spiNNaker as spinn
import numpy as np

from nealCoverClass import NealCoverFunctions
from FSAClass import FSAHelperFunctions

#---Below here are functions to test the system---
RUN_DURATION = 200

##--main---
neal = NealCoverFunctions(simulator)
fsa = FSAHelperFunctions(simulator)

fsa.testInit()

#setup input
spikeGenerators = fsa.testCreateTwoInputs()
firstSpikeGenerator =  spikeGenerators[0]
secondSpikeGenerator =  spikeGenerators[1]

#make neurons and make them recordable
stateCells = fsa.testCreateNeurons()
recorder = fsa.testCreateRecorder()
fsa.testSetupRecording(stateCells,recorder)

#build the fsa and run it
fsa.test3StateFSA(firstSpikeGenerator,secondSpikeGenerator,stateCells)
fsa.testRunFSA(RUN_DURATION)

#print results
fsa.testPrintResults(stateCells,recorder)



