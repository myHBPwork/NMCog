#This makes a 2 state FSA.  It does it without calling any of the 
#FSA test functions.  It should have the same results as testFSASmall.py.
#State 0, with input 1, turns on state 2.  2 turns off 1 and 0.

#change the simulator to run nest or spinnaker
simulator = "nest"
simulator = "spinnaker"


import nest as nest
import pyNN.spiNNaker as spinn
import numpy as np

from nealCoverClass import NealCoverFunctions
from FSAClass import FSAHelperFunctions

#---Below here are functions to test the system---
RUN_DURATION = 200
#initialize the simulator. 
def init():
    if fsa.simulator == "nest":
        nest.ResetKernel()
        nest.SetKernelStatus({'resolution':neal.DELAY})

    elif fsa.simulator == 'spinnaker':
        #print "spin"
        spinn.setup(timestep=neal.DELAY,min_delay=neal.DELAY,
                    max_delay=neal.DELAY, debug=0)

def createTwoInputs():
    inputSpikeTimes0 = [10.0]
    inputSpikeTimes1 = [50.0]
    if simulator == "nest":
        spikeGen0 = nest.Create('spike_generator',
            #params = {'spike_times': np.array([10.0,15.0, 20.0,25.0,30.0])})
            params = {'spike_times': np.array(inputSpikeTimes0)})

        spikeGen1 = nest.Create('spike_generator',
            params = {'spike_times': np.array(inputSpikeTimes1)})

        spikeDet = nest.Create('spike_detector')

    elif simulator == 'spinnaker':
        spikeArray0 = {'spike_times': [inputSpikeTimes0]}
        spikeGen0=spinn.Population(1,spinn.SpikeSourceArray,spikeArray0,
                                   label='inputSpikes_0')
        spikeArray1 = {'spike_times': [inputSpikeTimes1]}
        spikeGen1=spinn.Population(1, spinn.SpikeSourceArray, spikeArray1,
                                   label='inputSpikes_1')
    else: print "bad simulator for spike generator"

    return [spikeGen0,spikeGen1]


def createNeurons():
    if simulator == "nest":
        #in python Models() to see all the models including these
        #print GetDefaults (neuronType)

        cells = nest.Create("iaf_cond_exp",n=15,params = fsa.CELL_PARAMS)

    elif simulator == 'spinnaker':
        cells=spinn.Population(100,spinn.IF_cond_exp,fsa.CELL_PARAMS)

    return cells

def createRecorder():
    spikeDet = 0
    if simulator == "nest":
        spikeDet = nest.Create('spike_detector')

    #with spinnaker you can just set record on the cells
    return spikeDet

def setupRecording(cells, spikeDetector):
    if simulator == "nest":
        nest.Connect(cells,spikeDetector)

    elif simulator == 'spinnaker':
        cells.record()

def runFSA():
    if simulator == "nest":
        nest.Simulate(RUN_DURATION)

    elif simulator == 'spinnaker':
        spinn.run(RUN_DURATION)

def printResults(spinnCells,nestRecorder):
    #print
    if simulator == "nest":
        spikes = nest.GetStatus(nestRecorder)
        test = spikes[0]['events']['times']
        print 'spikes', test
    elif simulator == 'spinnaker':
        spinnCells.printSpikes('temp.sp')



##--main---
neal = NealCoverFunctions(simulator)
fsa = FSAHelperFunctions(simulator)

init()
spikeGenerators = createTwoInputs()
firstSpikeGenerator =  spikeGenerators[0]
secondSpikeGenerator =  spikeGenerators[1]

stateCells = createNeurons()

recorder = createRecorder()
setupRecording(stateCells,recorder)


#Build the FSA
fsa.turnOnState(firstSpikeGenerator,0,stateCells)
fsa.turnOnState(secondSpikeGenerator,1,stateCells)
fsa.makeCA(0, stateCells)
fsa.makeCA(1, stateCells)
fsa.makeCA(2, stateCells)
fsa.stateHalfTurnsOnState(0,2,stateCells)
fsa.stateTurnsOffState(2,0,stateCells)
#comment below out to check state 0 alone does not turn on state 2
fsa.stateHalfTurnsOnState(1,2,stateCells) 
fsa.stateTurnsOffState(2,1,stateCells)

runFSA()

printResults(stateCells,recorder)



