import nest as nest
import pyNN.spiNNaker as spinn


#Functions to isolate differences between different list synapse constructors
class NealCoverFunctions:
    def __init__(self, simName):
        self.DELAY = 1.0
        self.simulator = simName
        """
        if self.simulator == "nest":
            exec("from nest import *")
        elif self.simulator == 'spinnaker':
            exec("from pyNN.spiNNaker import *")

        else: print "bad simulator in nealFunctions"
        """

    def nealProjection(self,preNeurons,postNeurons, connectorList,inhExc):
        if self.simulator == "nest":
            #print 'nest', connectorList
            for connection in connectorList:
                nest.Connect(preNeurons[connection[0]],
                             postNeurons[connection[1]],
                             {'weight':connection[2]})
        elif self.simulator == 'spinnaker':
            connList = spinn.FromListConnector(connectorList)
            spinn.Projection(preNeurons, postNeurons, connList,target=inhExc) 
        else: print "bad simulator nealProjection"

