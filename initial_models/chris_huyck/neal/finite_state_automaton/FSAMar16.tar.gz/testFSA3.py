#This is a three state FSA.  The states are 0,2 and 4.  The inputs
#are 1, 3.  0 and 1 turn 2 on.  2 and 3 turn on 4. 4 turns off 2 and 3.
#3 turns off 1 and 2. 

#change the simulator here to run nest or spinnaker.
simulator = "nest"
simulator = "spinnaker"

import nest as nest
import pyNN.spiNNaker as spinn
import numpy as np

from nealCoverClass import NealCoverFunctions
from FSAClass import FSAHelperFunctions

#---Below here are functions to test the system---
RUN_DURATION = 200

def createThreeInputs():
    inputSpikeTimes0 = [10.0]
    inputSpikeTimes1 = [50.0]
    inputSpikeTimes2 = [100.0]
    if simulator == "nest":
        spikeGen0 = nest.Create('spike_generator',
            #params = {'spike_times': np.array([10.0,15.0, 20.0,25.0,30.0])})
            params = {'spike_times': np.array(inputSpikeTimes0)})

        spikeGen1 = nest.Create('spike_generator',
            params = {'spike_times': np.array(inputSpikeTimes1)})

        spikeGen2 = nest.Create('spike_generator',
            params = {'spike_times': np.array(inputSpikeTimes2)})

        spikeDet = nest.Create('spike_detector')

    elif simulator == 'spinnaker':
        spikeArray0 = {'spike_times': [inputSpikeTimes0]}
        spikeGen0=spinn.Population(1,spinn.SpikeSourceArray,spikeArray0,
                                   label='inputSpikes_0')
        spikeArray1 = {'spike_times': [inputSpikeTimes1]}
        spikeGen1=spinn.Population(1, spinn.SpikeSourceArray, spikeArray1,
                                   label='inputSpikes_1')

        spikeArray2 = {'spike_times': [inputSpikeTimes2]}
        spikeGen2=spinn.Population(1, spinn.SpikeSourceArray, spikeArray2,
                                   label='inputSpikes_2')
    else: print "bad simulator for spike generator"

    return [spikeGen0,spikeGen1,spikeGen2]

def createNeurons():
    if simulator == "nest":
        #in python Models() to see all the models including these
        #print GetDefaults (neuronType)

        cells = nest.Create("iaf_cond_exp",n=25,params = fsa.CELL_PARAMS)

    elif simulator == 'spinnaker':
        cells=spinn.Population(100,spinn.IF_cond_exp,fsa.CELL_PARAMS)

    return cells



##--main---
neal = NealCoverFunctions(simulator)
fsa = FSAHelperFunctions(simulator)

fsa.testInit()

#setup input
spikeGenerators = createThreeInputs()
firstSpikeGenerator =  spikeGenerators[0]
secondSpikeGenerator =  spikeGenerators[1]
thirdSpikeGenerator =  spikeGenerators[2]

#make neurons and make them recordable
stateCells = createNeurons()
recorder = fsa.testCreateRecorder()
fsa.testSetupRecording(stateCells,recorder)

#build the fsa and run it
#Build the FSA
fsa.turnOnState(firstSpikeGenerator,0,stateCells)
fsa.turnOnState(secondSpikeGenerator,1,stateCells)
#0 and 1 turn on 2
fsa.turnOnState(thirdSpikeGenerator,3,stateCells)
#2 and 3 turn on 4
fsa.makeCA(0, stateCells)
fsa.makeCA(1, stateCells)
fsa.makeCA(2, stateCells)
fsa.makeCA(3, stateCells)
fsa.makeCA(4, stateCells)
#0 and 1 turn on 2
fsa.stateHalfTurnsOnState(0,2,stateCells)
fsa.stateTurnsOffState(2,0,stateCells)
fsa.stateHalfTurnsOnState(1,2,stateCells) 
fsa.stateTurnsOffState(2,1,stateCells)
#2 and 3 turn on 4
fsa.stateHalfTurnsOnState(2,4,stateCells)
fsa.stateTurnsOffState(4,2,stateCells)
fsa.stateHalfTurnsOnState(3,4,stateCells)
fsa.stateTurnsOffState(4,3,stateCells)

#run the simulator
fsa.testRunFSA(RUN_DURATION)

#print results
fsa.testPrintResults(stateCells,recorder)



